# flrugrabber

To instasll use this code in your composer.json

```
"repositories": [
  {
    "type": "vcs",
    "url": "https://github.com/Dirst/flrugrabber"
  }
  ],
  "require": {
      "dirst/flrugrabber": "dev-master"
  }
}
```

Don't forget to enable classes autoloading in your project.

```php
require __DIR__ . "/vendor/autoload.php";
```
