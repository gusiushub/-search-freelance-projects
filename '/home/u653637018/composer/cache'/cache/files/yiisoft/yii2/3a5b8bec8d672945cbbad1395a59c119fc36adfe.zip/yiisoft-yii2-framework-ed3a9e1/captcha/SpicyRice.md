## Spicy Rice font

* **Author:** Brian J. Bonislawsky, Astigmatic (AOETI, Astigmatic One Eye Typographic Institute)
* **License:** SIL Open Font License (OFL), version 1.1, [notes and FAQ](http://scripts.sil.org/OFL)

## Links

* [Astigmatic](http://www.astigmatic.com/)
* [Google WebFonts](http://www.google.com/webfonts/specimen/Spicy+Rice)
* [fontsquirrel.com](http://www.fontsquirrel.com/fonts/spicy-rice)
* [fontspace.com](http://www.fontspace.com/astigmatic-one-eye-typographic-institute/spicy-rice)
