This is a paragraph with a newline  
next line

next par  
