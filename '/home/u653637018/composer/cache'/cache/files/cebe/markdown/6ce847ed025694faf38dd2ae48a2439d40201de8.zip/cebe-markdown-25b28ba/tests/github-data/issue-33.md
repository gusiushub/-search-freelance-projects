```
hey, check [this].

[this]: https://github.com/cebe/markdown
```
is a vaild reference.